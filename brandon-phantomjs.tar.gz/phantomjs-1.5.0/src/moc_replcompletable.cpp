/****************************************************************************
** Meta object code from reading C++ file 'replcompletable.h'
**
** Created: Sun Apr 1 00:06:54 2012
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "replcompletable.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'replcompletable.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_REPLCompletable[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // methods: signature, parameters, type, tag, flags
      22,   16,   17,   16, 0x02,
      68,   51,   39,   16, 0x02,

       0        // eod
};

static const char qt_meta_stringdata_REPLCompletable[] = {
    "REPLCompletable\0\0bool\0_isCompletable()\0"
    "QStringList\0prefixToComplete\0"
    "_getCompletions(QString)\0"
};

void REPLCompletable::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        REPLCompletable *_t = static_cast<REPLCompletable *>(_o);
        switch (_id) {
        case 0: { bool _r = _t->_isCompletable();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 1: { QStringList _r = _t->_getCompletions((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QStringList*>(_a[0]) = _r; }  break;
        default: ;
        }
    }
}

const QMetaObjectExtraData REPLCompletable::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject REPLCompletable::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_REPLCompletable,
      qt_meta_data_REPLCompletable, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &REPLCompletable::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *REPLCompletable::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *REPLCompletable::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_REPLCompletable))
        return static_cast<void*>(const_cast< REPLCompletable*>(this));
    return QObject::qt_metacast(_clname);
}

int REPLCompletable::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
