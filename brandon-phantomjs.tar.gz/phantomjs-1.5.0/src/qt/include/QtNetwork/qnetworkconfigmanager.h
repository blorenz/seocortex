#include "../../src/network/bearer/qnetworkconfigmanager.h"
