/****************************************************************************
** Meta object code from reading C++ file 'webpage.h'
**
** Created: Sun Apr 1 01:19:45 2012
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "webpage.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'webpage.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_WebPage[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      25,   14, // methods
       8,  139, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       8,       // signalCount

 // signals: signature, parameters, type, tag, flags
       9,    8,    8,    8, 0x05,
      23,    8,    8,    8, 0x05,
      44,   37,    8,    8, 0x05,
      70,   66,    8,    8, 0x05,
     107,   99,    8,    8, 0x05,
     163,  145,    8,    8, 0x05,
     209,  205,    8,    8, 0x05,
     246,  237,    8,    8, 0x05,

 // slots: signature, parameters, type, tag, flags
     293,  273,    8,    8, 0x0a,
     331,    8,    8,    8, 0x0a,
     362,  350,  341,    8, 0x0a,
     393,  388,  341,    8, 0x0a,
     425,  416,  411,    8, 0x0a,
     452,  441,  411,    8, 0x0a,
     480,  470,    8,    8, 0x0a,
     528,  510,    8,    8, 0x0a,
     571,  556,    8,    8, 0x0a,
     618,  608,    8,    8, 0x2a,
     651,  646,    8,    8, 0x2a,
     676,  670,    8,    8, 0x0a,
     691,  670,    8,    8, 0x0a,
     713,  670,    8,    8, 0x0a,
     741,  731,    8,    8, 0x0a,
     763,    8,    8,    8, 0x0a,
     779,  776,    8,    8, 0x08,

 // properties: name, type, flags
     800,  792, 0x0a095103,
     808,  792, 0x0a095001,
     818,  792, 0x0a095103,
     842,  830, 0x08095103,
     855,  830, 0x08095103,
     865,  830, 0x08095103,
     874,  830, 0x08095103,
     889,  830, 0x08095103,

       0        // eod
};

static const char qt_meta_stringdata_WebPage[] = {
    "WebPage\0\0initialized()\0loadStarted()\0"
    "status\0loadFinished(QString)\0msg\0"
    "javaScriptAlertSent(QString)\0message\0"
    "javaScriptConsoleMessageSent(QString)\0"
    "message,backtrace\0"
    "javaScriptErrorSent(QString,QVariantList)\0"
    "req\0resourceRequested(QVariant)\0"
    "resource\0resourceReceived(QVariant)\0"
    "address,op,settings\0"
    "openUrl(QString,QVariant,QVariantMap)\0"
    "release()\0QVariant\0code,params\0"
    "evaluate(QString,QString)\0code\0"
    "evaluate(QString)\0bool\0fileName\0"
    "render(QString)\0jsFilePath\0injectJs(QString)\0"
    "scriptUrl\0_appendScriptElement(QString)\0"
    "selector,fileName\0uploadFile(QString,QString)\0"
    "type,arg1,arg2\0sendEvent(QString,QVariant,QVariant)\0"
    "type,arg1\0sendEvent(QString,QVariant)\0"
    "type\0sendEvent(QString)\0value\0"
    "setEE(QString)\0setProxyType(QString)\0"
    "setProxy(QString)\0proxyauth\0"
    "setProxyAuth(QString)\0applyProxy()\0"
    "ok\0finish(bool)\0QString\0content\0"
    "plainText\0libraryPath\0QVariantMap\0"
    "viewportSize\0paperSize\0clipRect\0"
    "scrollPosition\0customHeaders\0"
};

void WebPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        WebPage *_t = static_cast<WebPage *>(_o);
        switch (_id) {
        case 0: _t->initialized(); break;
        case 1: _t->loadStarted(); break;
        case 2: _t->loadFinished((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->javaScriptAlertSent((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->javaScriptConsoleMessageSent((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 5: _t->javaScriptErrorSent((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QVariantList(*)>(_a[2]))); break;
        case 6: _t->resourceRequested((*reinterpret_cast< const QVariant(*)>(_a[1]))); break;
        case 7: _t->resourceReceived((*reinterpret_cast< const QVariant(*)>(_a[1]))); break;
        case 8: _t->openUrl((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QVariant(*)>(_a[2])),(*reinterpret_cast< const QVariantMap(*)>(_a[3]))); break;
        case 9: _t->release(); break;
        case 10: { QVariant _r = _t->evaluate((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< QVariant*>(_a[0]) = _r; }  break;
        case 11: { QVariant _r = _t->evaluate((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QVariant*>(_a[0]) = _r; }  break;
        case 12: { bool _r = _t->render((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 13: { bool _r = _t->injectJs((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 14: _t->_appendScriptElement((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 15: _t->uploadFile((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 16: _t->sendEvent((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QVariant(*)>(_a[2])),(*reinterpret_cast< const QVariant(*)>(_a[3]))); break;
        case 17: _t->sendEvent((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QVariant(*)>(_a[2]))); break;
        case 18: _t->sendEvent((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 19: _t->setEE((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 20: _t->setProxyType((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 21: _t->setProxy((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 22: _t->setProxyAuth((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 23: _t->applyProxy(); break;
        case 24: _t->finish((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData WebPage::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject WebPage::staticMetaObject = {
    { &REPLCompletable::staticMetaObject, qt_meta_stringdata_WebPage,
      qt_meta_data_WebPage, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &WebPage::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *WebPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *WebPage::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_WebPage))
        return static_cast<void*>(const_cast< WebPage*>(this));
    return REPLCompletable::qt_metacast(_clname);
}

int WebPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = REPLCompletable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = content(); break;
        case 1: *reinterpret_cast< QString*>(_v) = plainText(); break;
        case 2: *reinterpret_cast< QString*>(_v) = libraryPath(); break;
        case 3: *reinterpret_cast< QVariantMap*>(_v) = viewportSize(); break;
        case 4: *reinterpret_cast< QVariantMap*>(_v) = paperSize(); break;
        case 5: *reinterpret_cast< QVariantMap*>(_v) = clipRect(); break;
        case 6: *reinterpret_cast< QVariantMap*>(_v) = scrollPosition(); break;
        case 7: *reinterpret_cast< QVariantMap*>(_v) = customHeaders(); break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setContent(*reinterpret_cast< QString*>(_v)); break;
        case 2: setLibraryPath(*reinterpret_cast< QString*>(_v)); break;
        case 3: setViewportSize(*reinterpret_cast< QVariantMap*>(_v)); break;
        case 4: setPaperSize(*reinterpret_cast< QVariantMap*>(_v)); break;
        case 5: setClipRect(*reinterpret_cast< QVariantMap*>(_v)); break;
        case 6: setScrollPosition(*reinterpret_cast< QVariantMap*>(_v)); break;
        case 7: setCustomHeaders(*reinterpret_cast< QVariantMap*>(_v)); break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 8;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void WebPage::initialized()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void WebPage::loadStarted()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void WebPage::loadFinished(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void WebPage::javaScriptAlertSent(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void WebPage::javaScriptConsoleMessageSent(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void WebPage::javaScriptErrorSent(const QString & _t1, const QVariantList & _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void WebPage::resourceRequested(const QVariant & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void WebPage::resourceReceived(const QVariant & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}
QT_END_MOC_NAMESPACE
