/****************************************************************************
** Meta object code from reading C++ file 'phantom.h'
**
** Created: Sun Apr 1 00:06:54 2012
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "phantom.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'phantom.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Phantom[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       7,   99, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      14,    9,    8,    8, 0x05,

 // slots: signature, parameters, type, tag, flags
      40,    8,   31,    8, 0x0a,
      56,    8,   31,    8, 0x0a,
      74,    8,   31,    8, 0x0a,
      93,    8,   31,    8, 0x0a,
     121,  116,  108,    8, 0x0a,
     163,  152,  147,    8, 0x0a,
     181,    9,    8,    8, 0x0a,
     191,    8,    8,    8, 0x2a,
     198,    9,    8,    8, 0x0a,
     213,    8,    8,    8, 0x2a,
     231,  225,    8,    8, 0x0a,
     253,  225,    8,    8, 0x0a,
     281,  271,    8,    8, 0x0a,
     303,    8,    8,    8, 0x0a,
     320,  316,    8,    8, 0x08,
     349,    8,    8,    8, 0x08,

 // properties: name, type, flags
     377,  365, 0x0b095001,
     394,  382, 0x08095001,
     414,  108, 0x0a095103,
     426,  108, 0x0a095103,
     441,  108, 0x0a095001,
     452,  382, 0x08095001,
     460,   31, 0x88095001,

       0        // eod
};

static const char qt_meta_stringdata_Phantom[] = {
    "Phantom\0\0code\0aboutToExit(int)\0QObject*\0"
    "createWebPage()\0createWebServer()\0"
    "createFilesystem()\0createSystem()\0"
    "QString\0name\0loadModuleSource(QString)\0"
    "bool\0jsFilePath\0injectJs(QString)\0"
    "exit(int)\0exit()\0debugExit(int)\0"
    "debugExit()\0value\0setProxyType(QString)\0"
    "setProxy(QString)\0proxyauth\0"
    "setProxyAuth(QString)\0applyProxy()\0"
    "msg\0printConsoleMessage(QString)\0"
    "onInitialized()\0QStringList\0args\0"
    "QVariantMap\0defaultPageSettings\0"
    "libraryPath\0outputEncoding\0scriptName\0"
    "version\0page\0"
};

void Phantom::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        Phantom *_t = static_cast<Phantom *>(_o);
        switch (_id) {
        case 0: _t->aboutToExit((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: { QObject* _r = _t->createWebPage();
            if (_a[0]) *reinterpret_cast< QObject**>(_a[0]) = _r; }  break;
        case 2: { QObject* _r = _t->createWebServer();
            if (_a[0]) *reinterpret_cast< QObject**>(_a[0]) = _r; }  break;
        case 3: { QObject* _r = _t->createFilesystem();
            if (_a[0]) *reinterpret_cast< QObject**>(_a[0]) = _r; }  break;
        case 4: { QObject* _r = _t->createSystem();
            if (_a[0]) *reinterpret_cast< QObject**>(_a[0]) = _r; }  break;
        case 5: { QString _r = _t->loadModuleSource((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 6: { bool _r = _t->injectJs((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 7: _t->exit((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->exit(); break;
        case 9: _t->debugExit((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->debugExit(); break;
        case 11: _t->setProxyType((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 12: _t->setProxy((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 13: _t->setProxyAuth((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 14: _t->applyProxy(); break;
        case 15: _t->printConsoleMessage((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 16: _t->onInitialized(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData Phantom::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject Phantom::staticMetaObject = {
    { &REPLCompletable::staticMetaObject, qt_meta_stringdata_Phantom,
      qt_meta_data_Phantom, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Phantom::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Phantom::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Phantom::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Phantom))
        return static_cast<void*>(const_cast< Phantom*>(this));
    return REPLCompletable::qt_metacast(_clname);
}

int Phantom::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = REPLCompletable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QStringList*>(_v) = args(); break;
        case 1: *reinterpret_cast< QVariantMap*>(_v) = defaultPageSettings(); break;
        case 2: *reinterpret_cast< QString*>(_v) = libraryPath(); break;
        case 3: *reinterpret_cast< QString*>(_v) = outputEncoding(); break;
        case 4: *reinterpret_cast< QString*>(_v) = scriptName(); break;
        case 5: *reinterpret_cast< QVariantMap*>(_v) = version(); break;
        case 6: *reinterpret_cast< QObject**>(_v) = page(); break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 2: setLibraryPath(*reinterpret_cast< QString*>(_v)); break;
        case 3: setOutputEncoding(*reinterpret_cast< QString*>(_v)); break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 7;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void Phantom::aboutToExit(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
