#ifndef QT_NO_QT_INCLUDE_WARN
    #if defined(__GNUC__)
        #warning "Inclusion of header files from include/Qt is deprecated."
    #elif defined(_MSC_VER)
        #pragma message("WARNING: Inclusion of header files from include/Qt is deprecated.")
    #endif
#endif

#include "../QtXmlPatterns/qxmlserializer.h"
