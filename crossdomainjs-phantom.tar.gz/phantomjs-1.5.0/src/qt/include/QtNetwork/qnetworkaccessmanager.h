#include "../../src/network/access/qnetworkaccessmanager.h"
